vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
animations.model.NotMeow:setPlaying(true)
local bool hat = false
local bool hand = false
local bool meow = false
models:setSecondaryRenderType("Eyes")
function events.entity_init()
    animations.model.Idle:setPlaying(true)

    local hatKey = keybinds:newKeybind("Play Animation", "key.keyboard.h")
    local handKey = keybinds:newKeybind("Play Animation", "key.keyboard.k")
    local meowKey = keybinds:newKeybind("Play Animation", "key.keyboard.y")

    function hatKey.press()
        hat = not hat
    end
    function handKey.press()
        hand = not hand
    end


    function meowKey.press()
	meow = true
        sounds:playSound("entity.cat.ambient",player:getPos())
	animations.model.NotMeow:setPlaying(false)
        animations.model.Meow:setPlaying(true)
	animations.model.NotMeow:setPlaying(true)
    end
end
function events.tick()
    
    local crouching = player:getPose() == "CROUCHING"

    local walking = player:getVelocity().xz:length() > .01

    local sprinting = player:isSprinting()






    animations.model.Walk:setPlaying((walking or sprinting) and not crouching)
    animations.model.Crouch:setPlaying(crouching)
    animations.model.HatOff:setPlaying(hat)
    animations.model.HatOn:setPlaying(not hat)
    animations.model.SleeveOff:setPlaying(hand)
    meow = false



end