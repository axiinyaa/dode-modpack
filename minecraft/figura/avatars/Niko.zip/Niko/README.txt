Hai! Just wanted to keep some notes here ^^

--Do NOT port or utilize this model anywhere else! This model is extremely private, and I would only like it to be
used the way it was intended to, either by who I trust, or in this port. I kindly ask you to not take advantage of
it and porting to another program, and if you really want to, ASK ME FOR PERMISSION before doing so.--

ACTION KEYS:

H: Toggles hat on/off
K: Toggles sleeve on/off
Y: meow


I (@noanhg_) made this model, but all the credits to the Figura port goes to MUI Noam(@mui-noam.bsky.social).
He did all the porting and fixes that were needed all by himself!
Big props to him, genuinely <3

--Have fun!--

https://x.com/noanhg_
@mui-noam.bsky.social
